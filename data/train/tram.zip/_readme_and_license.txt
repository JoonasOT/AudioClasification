Sound pack downloaded from Freesound
----------------------------------------

"tram_data"

This pack of sounds contains sounds by the following user:
 - projectsgn120thinhmanh ( https://freesound.org/people/projectsgn120thinhmanh/ )

You can find this pack online at: https://freesound.org/people/projectsgn120thinhmanh/packs/42202/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 768816__projectsgn120thinhmanh__tram_9.m4a
    * url: https://freesound.org/s/768816/
    * license: Creative Commons 0
  * 768815__projectsgn120thinhmanh__tram_8.m4a
    * url: https://freesound.org/s/768815/
    * license: Creative Commons 0
  * 768814__projectsgn120thinhmanh__tram_7.m4a
    * url: https://freesound.org/s/768814/
    * license: Creative Commons 0
  * 768813__projectsgn120thinhmanh__tram_6.m4a
    * url: https://freesound.org/s/768813/
    * license: Creative Commons 0
  * 768812__projectsgn120thinhmanh__tram_5.m4a
    * url: https://freesound.org/s/768812/
    * license: Creative Commons 0
  * 768811__projectsgn120thinhmanh__tram_4.m4a
    * url: https://freesound.org/s/768811/
    * license: Creative Commons 0
  * 768800__projectsgn120thinhmanh__tram_36.m4a
    * url: https://freesound.org/s/768800/
    * license: Creative Commons 0
  * 768799__projectsgn120thinhmanh__tram_35.m4a
    * url: https://freesound.org/s/768799/
    * license: Creative Commons 0
  * 768798__projectsgn120thinhmanh__tram_34.m4a
    * url: https://freesound.org/s/768798/
    * license: Creative Commons 0
  * 768797__projectsgn120thinhmanh__tram_33.m4a
    * url: https://freesound.org/s/768797/
    * license: Creative Commons 0
  * 768796__projectsgn120thinhmanh__tram_32.m4a
    * url: https://freesound.org/s/768796/
    * license: Creative Commons 0
  * 768795__projectsgn120thinhmanh__tram_31.m4a
    * url: https://freesound.org/s/768795/
    * license: Creative Commons 0
  * 768794__projectsgn120thinhmanh__tram_30.m4a
    * url: https://freesound.org/s/768794/
    * license: Creative Commons 0
  * 768793__projectsgn120thinhmanh__tram_3.m4a
    * url: https://freesound.org/s/768793/
    * license: Creative Commons 0
  * 768792__projectsgn120thinhmanh__tram_29.m4a
    * url: https://freesound.org/s/768792/
    * license: Creative Commons 0
  * 768791__projectsgn120thinhmanh__tram_28.m4a
    * url: https://freesound.org/s/768791/
    * license: Creative Commons 0
  * 768780__projectsgn120thinhmanh__tram_27.m4a
    * url: https://freesound.org/s/768780/
    * license: Creative Commons 0
  * 768779__projectsgn120thinhmanh__tram_26.m4a
    * url: https://freesound.org/s/768779/
    * license: Creative Commons 0
  * 768778__projectsgn120thinhmanh__tram_25.m4a
    * url: https://freesound.org/s/768778/
    * license: Creative Commons 0
  * 768777__projectsgn120thinhmanh__tram_24.m4a
    * url: https://freesound.org/s/768777/
    * license: Creative Commons 0
  * 768776__projectsgn120thinhmanh__tram_23.m4a
    * url: https://freesound.org/s/768776/
    * license: Creative Commons 0
  * 768775__projectsgn120thinhmanh__tram_22.m4a
    * url: https://freesound.org/s/768775/
    * license: Creative Commons 0
  * 768774__projectsgn120thinhmanh__tram_21.m4a
    * url: https://freesound.org/s/768774/
    * license: Creative Commons 0
  * 768773__projectsgn120thinhmanh__tram_20.m4a
    * url: https://freesound.org/s/768773/
    * license: Creative Commons 0
  * 768772__projectsgn120thinhmanh__tram_2.m4a
    * url: https://freesound.org/s/768772/
    * license: Creative Commons 0
  * 768771__projectsgn120thinhmanh__tram_19.m4a
    * url: https://freesound.org/s/768771/
    * license: Creative Commons 0
  * 768760__projectsgn120thinhmanh__tram_18.m4a
    * url: https://freesound.org/s/768760/
    * license: Creative Commons 0
  * 768759__projectsgn120thinhmanh__tram_17.m4a
    * url: https://freesound.org/s/768759/
    * license: Creative Commons 0
  * 768758__projectsgn120thinhmanh__tram_16.m4a
    * url: https://freesound.org/s/768758/
    * license: Creative Commons 0
  * 768757__projectsgn120thinhmanh__tram_15.m4a
    * url: https://freesound.org/s/768757/
    * license: Creative Commons 0
  * 768756__projectsgn120thinhmanh__tram_14.m4a
    * url: https://freesound.org/s/768756/
    * license: Creative Commons 0
  * 768755__projectsgn120thinhmanh__tram_13.m4a
    * url: https://freesound.org/s/768755/
    * license: Creative Commons 0
  * 768754__projectsgn120thinhmanh__tram_12.m4a
    * url: https://freesound.org/s/768754/
    * license: Creative Commons 0
  * 768753__projectsgn120thinhmanh__tram_11.m4a
    * url: https://freesound.org/s/768753/
    * license: Creative Commons 0
  * 768752__projectsgn120thinhmanh__tram_10.m4a
    * url: https://freesound.org/s/768752/
    * license: Creative Commons 0
  * 768751__projectsgn120thinhmanh__tram_1.m4a
    * url: https://freesound.org/s/768751/
    * license: Creative Commons 0


