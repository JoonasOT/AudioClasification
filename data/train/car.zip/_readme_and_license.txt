Sound pack downloaded from Freesound
----------------------------------------

"Car sound in Tampere"

This pack of sounds contains sounds by the following user:
 - car_sound ( https://freesound.org/people/car_sound/ )

You can find this pack online at: https://freesound.org/people/car_sound/packs/36876/


Pack description
----------------

Recorded with Iphone X


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 660052__car-sound__car42.wav
    * url: https://freesound.org/s/660052/
    * license: Creative Commons 0
  * 660051__car-sound__car43.wav
    * url: https://freesound.org/s/660051/
    * license: Creative Commons 0
  * 660050__car-sound__car40.wav
    * url: https://freesound.org/s/660050/
    * license: Creative Commons 0
  * 660049__car-sound__car41.wav
    * url: https://freesound.org/s/660049/
    * license: Creative Commons 0
  * 660048__car-sound__car39.wav
    * url: https://freesound.org/s/660048/
    * license: Creative Commons 0
  * 660047__car-sound__car4.wav
    * url: https://freesound.org/s/660047/
    * license: Creative Commons 0
  * 660046__car-sound__car37.wav
    * url: https://freesound.org/s/660046/
    * license: Creative Commons 0
  * 660045__car-sound__car38.wav
    * url: https://freesound.org/s/660045/
    * license: Creative Commons 0
  * 660044__car-sound__car44.wav
    * url: https://freesound.org/s/660044/
    * license: Creative Commons 0
  * 660043__car-sound__car45.wav
    * url: https://freesound.org/s/660043/
    * license: Creative Commons 0
  * 660041__car-sound__car26.wav
    * url: https://freesound.org/s/660041/
    * license: Creative Commons 0
  * 660040__car-sound__car27.wav
    * url: https://freesound.org/s/660040/
    * license: Creative Commons 0
  * 660039__car-sound__car22.wav
    * url: https://freesound.org/s/660039/
    * license: Creative Commons 0
  * 660038__car-sound__car23.wav
    * url: https://freesound.org/s/660038/
    * license: Creative Commons 0
  * 660037__car-sound__car24.wav
    * url: https://freesound.org/s/660037/
    * license: Creative Commons 0
  * 660036__car-sound__car25.wav
    * url: https://freesound.org/s/660036/
    * license: Creative Commons 0
  * 660035__car-sound__car19.wav
    * url: https://freesound.org/s/660035/
    * license: Creative Commons 0
  * 660034__car-sound__car2.wav
    * url: https://freesound.org/s/660034/
    * license: Creative Commons 0
  * 660033__car-sound__car20.wav
    * url: https://freesound.org/s/660033/
    * license: Creative Commons 0
  * 660032__car-sound__car21.wav
    * url: https://freesound.org/s/660032/
    * license: Creative Commons 0
  * 660031__car-sound__car9.wav
    * url: https://freesound.org/s/660031/
    * license: Creative Commons 0
  * 660030__car-sound__car8.wav
    * url: https://freesound.org/s/660030/
    * license: Creative Commons 0
  * 660029__car-sound__car49.wav
    * url: https://freesound.org/s/660029/
    * license: Creative Commons 0
  * 660028__car-sound__car32.wav
    * url: https://freesound.org/s/660028/
    * license: Creative Commons 0
  * 660027__car-sound__car31.wav
    * url: https://freesound.org/s/660027/
    * license: Creative Commons 0
  * 660026__car-sound__car34.wav
    * url: https://freesound.org/s/660026/
    * license: Creative Commons 0
  * 660025__car-sound__car33.wav
    * url: https://freesound.org/s/660025/
    * license: Creative Commons 0
  * 660024__car-sound__car29.wav
    * url: https://freesound.org/s/660024/
    * license: Creative Commons 0
  * 660023__car-sound__car28.wav
    * url: https://freesound.org/s/660023/
    * license: Creative Commons 0
  * 660022__car-sound__car30.wav
    * url: https://freesound.org/s/660022/
    * license: Creative Commons 0
  * 660021__car-sound__car3.wav
    * url: https://freesound.org/s/660021/
    * license: Creative Commons 0
  * 660020__car-sound__car7.wav
    * url: https://freesound.org/s/660020/
    * license: Creative Commons 0
  * 660019__car-sound__car6.wav
    * url: https://freesound.org/s/660019/
    * license: Creative Commons 0
  * 660018__car-sound__car50.wav
    * url: https://freesound.org/s/660018/
    * license: Creative Commons 0
  * 660017__car-sound__car5.wav
    * url: https://freesound.org/s/660017/
    * license: Creative Commons 0
  * 660016__car-sound__car36.wav
    * url: https://freesound.org/s/660016/
    * license: Creative Commons 0
  * 660015__car-sound__car35.wav
    * url: https://freesound.org/s/660015/
    * license: Creative Commons 0
  * 660014__car-sound__car47.wav
    * url: https://freesound.org/s/660014/
    * license: Creative Commons 0
  * 660013__car-sound__car46.wav
    * url: https://freesound.org/s/660013/
    * license: Creative Commons 0
  * 660012__car-sound__car48.wav
    * url: https://freesound.org/s/660012/
    * license: Creative Commons 0
  * 660011__car-sound__car17.wav
    * url: https://freesound.org/s/660011/
    * license: Creative Commons 0
  * 660010__car-sound__car18.wav
    * url: https://freesound.org/s/660010/
    * license: Creative Commons 0
  * 660009__car-sound__car13.wav
    * url: https://freesound.org/s/660009/
    * license: Creative Commons 0
  * 660008__car-sound__car14.wav
    * url: https://freesound.org/s/660008/
    * license: Creative Commons 0
  * 660007__car-sound__car15.wav
    * url: https://freesound.org/s/660007/
    * license: Creative Commons 0
  * 660006__car-sound__car16.wav
    * url: https://freesound.org/s/660006/
    * license: Creative Commons 0
  * 660005__car-sound__car1.wav
    * url: https://freesound.org/s/660005/
    * license: Creative Commons 0
  * 660004__car-sound__car10.wav
    * url: https://freesound.org/s/660004/
    * license: Creative Commons 0
  * 660003__car-sound__car11.wav
    * url: https://freesound.org/s/660003/
    * license: Creative Commons 0
  * 660002__car-sound__car12.wav
    * url: https://freesound.org/s/660002/
    * license: Creative Commons 0


